package com.cg.onlineshop.beans;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Product {
@Id
private int productId;
private String productCode;
private int price;
private int starRating;
private String description;
private String productName;
private String releaseDate;
public Product(int productId, String productCode, int price, int starRating, String description, String productName,
		String releaseDate) {
	super();
	this.productId = productId;
	this.productCode = productCode;
	this.price = price;
	this.starRating = starRating;
	this.description = description;
	this.productName = productName;
	this.releaseDate = releaseDate;
}

}
