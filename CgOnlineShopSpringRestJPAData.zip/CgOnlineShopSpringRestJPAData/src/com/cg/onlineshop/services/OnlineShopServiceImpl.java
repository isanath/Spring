package com.cg.onlineshop.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.onlineshop.beans.Product;
import com.cg.onlineshop.daoservices.ProductDAO;
import com.cg.onlineshop.exceptions.ProductDetailsNotFoundException;

@Component(value="onlineShopServices")
public class OnlineShopServiceImpl implements OnlineShopServices{
    @Autowired
	ProductDAO productDAO;
    
	@Override
	public Product acceptProductDetails(Product product) {
       
		return productDAO.save(product);
	}

	@Override
	public List<Product> getAllProducts() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Product getProductDetails(int productId) throws ProductDetailsNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void removeProductDetails(int productId) {
		// TODO Auto-generated method stub
		
	}

}
