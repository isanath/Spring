package com.cg.onlineshop.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.onlineshop.beans.Product;
import com.cg.onlineshop.services.OnlineShopServices;

@RestController
public class ProductCatlogController {
	@Autowired 
	OnlineShopServices onlineShopServices;
      @RequestMapping("/hello")
	public ResponseEntity<String> sayHello(){
	  ResponseEntity<String> response=new ResponseEntity<String>("Hello to All",HttpStatus.OK);
	  return response;
  }
      @RequestMapping(value="/acceptProductDetails",method=RequestMethod.POST,
    		  consumes=MediaType.APPLICATION_FORM_URLENCODED_VALUE)
      public ResponseEntity<String> acceptProductDetails(@ModelAttribute Product product){
    	  onlineShopServices.acceptProductDetails(product);
    	  return new ResponseEntity<String>("Product Details Successfullt added",HttpStatus.OK);
      }

}
